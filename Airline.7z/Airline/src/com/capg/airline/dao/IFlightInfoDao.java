/**
 * 
 */
package com.capg.airline.dao;

import java.sql.SQLException;

import javax.naming.NamingException;

import com.capg.airline.bean.FlightInformation;
import com.capg.airline.exception.AirlineException;

/**
 * @author CAPG
 *
 */
public interface IFlightInfoDao {

	public FlightInformation getAirplaneInfo(FlightInformation flightInformation);

	public FlightInformation fetchFlight(FlightInformation flightInformation);

	public FlightInformation addFlight();

	public FlightInformation deleteFlight(String FlightNo);

	public FlightInformation updateFlight(String flightNo);

	public FlightInformation viewFlight(FlightInformation flightInformation);

	public String updateFlight(String mod, String id1) throws NamingException, SQLException, AirlineException;

}

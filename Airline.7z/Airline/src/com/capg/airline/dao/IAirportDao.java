/**
 * 
 */
package com.capg.airline.dao;

import com.capg.airline.bean.AirportBean;
import com.capg.airline.bean.FlightInformation;

/**
 * @author CAPG
 *
 */
public interface IAirportDao {

	AirportBean fetchDetails(AirportBean airportBean,FlightInformation flightInformation);

	AirportBean occupancyDetails(AirportBean airportBean,FlightInformation flightInformation);

}

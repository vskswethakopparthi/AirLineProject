/**
 * 
 */
package com.capg.airline.bean;

/**
 * @author CAPG
 *
 */
public class BookingInformation {

	private String bookingId;
	private String custEmaiil;
	private int noOfPassengers;
	private String classType;
	private double totalFare;
	private String seatNumber;
	private String cerditCardInfo;
	private String srcCity;
	private String destCity;

	/**
	 * @return the bookingId
	 */
	public String getBookingId() {
		return bookingId;
	}

	/**
	 * @param bookingId
	 *            the bookingId to set
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	/**
	 * @return the custEmaiil
	 */
	public String getCustEmaiil() {
		return custEmaiil;
	}

	/**
	 * @param custEmaiil
	 *            the custEmaiil to set
	 */
	public void setCustEmaiil(String custEmaiil) {
		this.custEmaiil = custEmaiil;
	}

	/**
	 * @return the noOfPassengers
	 */
	public int getNoOfPassengers() {
		return noOfPassengers;
	}

	/**
	 * @param noOfPassengers
	 *            the noOfPassengers to set
	 */
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}

	/**
	 * @return the classType
	 */
	public String getClassType() {
		return classType;
	}

	/**
	 * @param classType
	 *            the classType to set
	 */
	public void setClassType(String classType) {
		this.classType = classType;
	}

	/**
	 * @return the totalFare
	 */
	public double getTotalFare() {
		return totalFare;
	}

	/**
	 * @param totalFare
	 *            the totalFare to set
	 */
	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}

	/**
	 * @return the seatNumber
	 */
	public String getSeatNumber() {
		return seatNumber;
	}

	/**
	 * @param seatNumber
	 *            the seatNumber to set
	 */
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}

	/**
	 * @return the cerditCardInfo
	 */
	public String getCerditCardInfo() {
		return cerditCardInfo;
	}

	/**
	 * @param cerditCardInfo
	 *            the cerditCardInfo to set
	 */
	public void setCerditCardInfo(String cerditCardInfo) {
		this.cerditCardInfo = cerditCardInfo;
	}

	/**
	 * @return the srcCity
	 */
	public String getSrcCity() {
		return srcCity;
	}

	/**
	 * @param srcCity
	 *            the srcCity to set
	 */
	public void setSrcCity(String srcCity) {
		this.srcCity = srcCity;
	}

	/**
	 * @return the destCity
	 */
	public String getDestCity() {
		return destCity;
	}

	/**
	 * @param destCity
	 *            the destCity to set
	 */
	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}

	/**
	 * 
	 */
	public BookingInformation() {
		// TODO Auto-generated constructor stub
	}

}

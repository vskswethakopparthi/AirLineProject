/**
 * 
 */
package com.capg.airline.service;

import java.sql.SQLException;

import javax.naming.NamingException;

import com.capg.airline.bean.UsersBean;
import com.capg.airline.dao.IUserDao;
import com.capg.airline.dao.UserDaoImpl;
import com.capg.airline.exception.AirlineException;

/**
 * @author CAPG
 *
 */
public class UserServiceImpl implements IUserService {

	IUserDao iUserDao;

	/** 
	*/
	public UserServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public UsersBean getAuthentication(UsersBean usersBean) {
		// TODO Auto-generated method stub
		try {
			iUserDao = new UserDaoImpl();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			
		}
		return iUserDao.getAuthentication(usersBean);

	}

	@Override
	public UsersBean createUser(UsersBean usersBean) {
		// TODO Auto-generated method stub
		return iUserDao.createUser(usersBean);
	}

}

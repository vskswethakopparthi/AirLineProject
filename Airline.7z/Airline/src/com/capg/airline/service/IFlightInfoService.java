/**
 * 
 */
package com.capg.airline.service;

import java.sql.SQLException;

import javax.naming.NamingException;

import com.capg.airline.bean.FlightInformation;
import com.capg.airline.bean.UsersBean;
import com.capg.airline.exception.AirlineException;

/**
 * @author CAPG
 *
 */
public interface IFlightInfoService {

	public FlightInformation getAirplaneInfo(FlightInformation flightInformation);

	public FlightInformation fetchFlight(FlightInformation flightInformation);

	public FlightInformation addFlight();

	public FlightInformation deleteFlight(String flightNo);

	public FlightInformation updateFlight(String flightNo);

	public FlightInformation viewFlight(FlightInformation flightInformation);

	public void update(String mod, String id1) throws NamingException, SQLException, AirlineException;
}

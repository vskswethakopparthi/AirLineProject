/**
 * 
 */
package com.capg.airline.service;

import com.capg.airline.bean.AirportBean;
import com.capg.airline.bean.FlightInformation;
import com.capg.airline.dao.AirportDaoImpl;
import com.capg.airline.dao.IAirportDao;

/**
 * @author CAPG
 *
 */
public class AirportServiceImpl implements IAirportService {

	IAirportDao iAirportDao;
	/**
	 * 
	 */
	public AirportServiceImpl() {
		// TODO Auto-generated constructor stub
		iAirportDao=new AirportDaoImpl();
	}

	@Override
	public AirportBean fetchDetails(AirportBean airportBean,FlightInformation flightInformation) {
		// TODO Auto-generated method stub
		return iAirportDao.fetchDetails(airportBean,flightInformation);
	}

	@Override
	public AirportBean occupancyDetails(AirportBean airportBean, FlightInformation flightInformation) {
		// TODO Auto-generated method stub
		return iAirportDao.occupancyDetails(airportBean,flightInformation);
	}

}

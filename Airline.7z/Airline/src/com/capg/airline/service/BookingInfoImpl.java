/**
 * 
 */
package com.capg.airline.service;

import com.capg.airline.bean.BookingInformation;
import com.capg.airline.bean.FlightInformation;
import com.capg.airline.dao.BookingInfodaoImpl;
import com.capg.airline.dao.IBookingInfoDao;

/**
 * @author CAPG
 *
 */
public class BookingInfoImpl implements IBookingInfoService {

	IBookingInfoDao iBookingInfoDao;

	/**
	 * 
	 */
	public BookingInfoImpl() {
		iBookingInfoDao = new BookingInfodaoImpl();
	}

	@Override
	public BookingInformation confirmBooking(BookingInformation bookingInformation,
			FlightInformation flightInformation) {
		// TODO Auto-generated method stub

		return iBookingInfoDao.confirmBooking(bookingInformation, flightInformation);
	}

	@Override
	public void displayBooking(BookingInformation bookingInformation) {
		iBookingInfoDao.displayBooking(bookingInformation);

	}

	@Override
	public void cancelBooking(BookingInformation bookingInformation,FlightInformation flightInformation) {
		// TODO Auto-generated method stub
		iBookingInfoDao.cancelBooking(bookingInformation,flightInformation);

	}

}

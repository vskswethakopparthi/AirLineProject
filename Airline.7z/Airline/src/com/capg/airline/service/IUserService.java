/**
 * 
 */
package com.capg.airline.service;

import com.capg.airline.bean.UsersBean;

/**
 * @author CAPG
 *
 */
public interface IUserService {

	public UsersBean getAuthentication(UsersBean usersBean);

	public UsersBean createUser(UsersBean usersBean);

}

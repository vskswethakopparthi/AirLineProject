/**
 * 
 */
package testcases.com.capg.airline.testcase;

import static org.junit.Assert.assertNotNull;

import java.util.logging.Logger;


import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.airline.bean.FlightInformation;
import com.capg.airline.dao.FlightInfDaooImpl;
import com.capg.airline.exception.AirlineException;



/**
 * @author Cg
 *
 */
public class Test1 {

	static FlightInfDaooImpl flightdao=null;
	static Logger logger=Logger.getAnonymousLogger();
	static FlightInformation flightInformation=null;

	@BeforeClass
	public static void intialize()
	{
		flightdao=new FlightInfDaooImpl();
		flightInformation=new FlightInformation();
	}
	@Test
	//------------------------ 1.Airline Book --------------------------
		/*******************************************************************************************************
					 - Function Name	:	fetchFlightNullTest()
					 - Input Parameters	:	No Parameter
					 - Return Type		:	Void
					 - Throws		    :   AirlineException
					 - Author		    :   Team 1
					 - Creation Date	:	7/04/2018
					 - Description		:	Testing the fetchFlight() method 
		 ********************************************************************************************************/
	public void fetchFlightNullTest() throws AirlineException {
		flightInformation.setFlightNo("12345");
		assertNotNull(flightdao.fetchFlight(flightInformation));
	}
}
